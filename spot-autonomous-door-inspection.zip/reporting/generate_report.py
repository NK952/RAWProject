print('Generate report')
