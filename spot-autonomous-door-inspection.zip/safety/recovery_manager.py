print('Recovery manager')
