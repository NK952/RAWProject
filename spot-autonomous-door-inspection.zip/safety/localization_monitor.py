print('Localization monitor')
