print('Safety logger')
