print('Capture image placeholder')
