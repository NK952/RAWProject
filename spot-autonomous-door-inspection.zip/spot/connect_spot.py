print('Connect Spot placeholder')
