print('Lock detector')
