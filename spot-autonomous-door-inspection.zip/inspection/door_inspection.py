print('Door inspection')
