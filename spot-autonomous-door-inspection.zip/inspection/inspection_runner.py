print('Inspection runner')
