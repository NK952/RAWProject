# Spot Autonomous Door Inspection
